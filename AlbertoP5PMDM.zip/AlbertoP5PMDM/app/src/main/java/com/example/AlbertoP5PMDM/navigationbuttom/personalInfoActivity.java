package com.example.violetang.navigationbuttom;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Author: Runyu Xu
 * Date: Nov. 2018
 */
public class personalInfoActivity extends AppCompatActivity {


}
