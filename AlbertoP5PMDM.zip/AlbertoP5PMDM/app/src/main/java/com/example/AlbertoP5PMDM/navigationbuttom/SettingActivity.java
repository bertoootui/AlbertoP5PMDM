package com.example.violetang.navigationbuttom;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

/**
 * Author: Jiali
 * Date: Nov. 2018
 * Description: didn't use, save for future development
 */
public class SettingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);

        Intent SettingInfo_Intent = getIntent();
    }
}
