# Android studio-To do List
<img width="748" alt="screen shot 2019-01-18 at 11 33 23 pm" src="https://user-images.githubusercontent.com/34366585/51423796-168fe580-1b7a-11e9-9020-3b5967d6d2ec.png">

<img width="722" alt="screen shot 2019-01-18 at 11 37 28 pm" src="https://user-images.githubusercontent.com/34366585/51423802-290a1f00-1b7a-11e9-8994-a09d166e2185.png">
